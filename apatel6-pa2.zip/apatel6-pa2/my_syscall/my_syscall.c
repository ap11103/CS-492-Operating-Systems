#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/uaccess.h>

//asymlinkage long apatel6_syscall(char __user *str)
SYSCALL_DEFINE1(apatel6_syscall, char __user *, str){
    //checking if the arr is NULL
    if(str == NULL){
      return -1;
    }
        
    //check if the string length is larger 32 -> return -1
    if(strnlen_user(str, 33) > 32){
      return -1;
    }
    
    //copy the string from user to kernel space
    //a buffer to copy string into
    char buff[33];
    if(copy_from_user(buff, str, sizeof(buff))){
      return -1;
    }
    //print the original str
    printk(KERN_INFO "before: %s\n", buff);
    
    //replace the occurrences of a lowercase vowel letter with first letter of apatel6
    //char replace = 'A';
    int count = 0;
    for(int i = 0; buff[i] != '\0'; i++){
      if(buff[i] == 'a' || buff[i] == 'e' || buff[i] == 'i' || buff[i] == 'o' || buff[i] == 'o'){
        buff[i] = 'A';
        count++;
      }
    }
    
    //use printk to print the modified string
    printk(KERN_INFO "after: %s\n", buff);
    
    //copies the modified string from kernel to user
    if(copy_to_user(str, buff, sizeof(buff))){
      return -1;
    }
    //return the counted number of character replacements
    return count;
}
