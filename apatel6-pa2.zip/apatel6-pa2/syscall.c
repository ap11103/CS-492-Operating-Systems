#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
  char big_arr[] = "The quick brown fox jumps over the lazy dog";
  char sm_arr[] = "osconceptsandstructures";
  
  //test case 1: str larger than 32
  printf("Before syscall: %s\n", big_arr);
  long big_result = syscall(451, big_arr);
  printf("Return value of syscall: %ld\n", big_result);
  printf("After syscall: %s\n", big_arr);
  
  //test case 2: str smaller than 32
  printf("Before syscall: %s\n", sm_arr);
  long sm_result = syscall(451, sm_arr);
  printf("Return value of syscall: %ld\n", sm_result);
  printf("After syscall: %s\n", sm_arr);
  
  return 0;  
}

