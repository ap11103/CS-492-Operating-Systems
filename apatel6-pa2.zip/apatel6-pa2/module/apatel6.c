#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>

int hello_init(void){
  //char msg[] = "Hello World from Alisha Patel (apatel6)\n";
  //int nr = SYS_write;
  printk(KERN_ALERT "Hello World from Alisha Patel (apatel6)\n"); 
  return 0;
}

void hello_exit(void){
  printk(KERN_ALERT "PID IS %d and program name is %s\n", current->pid, current->comm);
  
}

module_init(hello_init); 
module_exit(hello_exit);
MODULE_LICENSE("Dual BSD/GPL");
